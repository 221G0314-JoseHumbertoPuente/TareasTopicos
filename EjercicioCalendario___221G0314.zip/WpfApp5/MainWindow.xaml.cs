﻿using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp5
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        private DateTime _fechaSeleccionada;

        public event PropertyChangedEventHandler? PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public DateTime FechaSeleccionada
        {
            get { return _fechaSeleccionada; }
            set
            {
                _fechaSeleccionada = value;
                OnPropertyChanged(nameof(FechaSeleccionada));
                ActualizarDiasMes();
            }
        }

        public List<DiaViewModel> DiasMes { get; set; }
        public MainWindow()
        {
            InitializeComponent();
            FechaSeleccionada = DateTime.Now;
            DataContext = this;
        }
        private void ActualizarDiasMes()
        {
            DiasMes = new List<DiaViewModel>();
            DateTime primerDiaMes = new DateTime(FechaSeleccionada.Year, FechaSeleccionada.Month, 1);
            int diaSemanaPrimerDia = (int)primerDiaMes.DayOfWeek;

            // Rellenar días del mes anterior si es necesario
            for (int i = 0; i < diaSemanaPrimerDia; i++)
            {
                DateTime diaAnterior = primerDiaMes.AddDays(-diaSemanaPrimerDia + i);
                DiasMes.Add(new DiaViewModel { Dia = diaAnterior.Day, EsDiaDelMes = false });
            }

            // Rellenar días del mes actual
            int diasEnMes = DateTime.DaysInMonth(FechaSeleccionada.Year, FechaSeleccionada.Month);
            for (int i = 1; i <= diasEnMes; i++)
            {
                DiasMes.Add(new DiaViewModel { Dia = i, EsDiaDelMes = true });
            }

            // Rellenar días del mes siguiente si es necesario
            int diasRestantes = 42 - DiasMes.Count;
            for (int i = 1; i <= diasRestantes; i++)
            {
                DateTime diaSiguiente = primerDiaMes.AddMonths(1).AddDays(i - 1);
                DiasMes.Add(new DiaViewModel { Dia = diaSiguiente.Day, EsDiaDelMes = false });
            }

            OnPropertyChanged(nameof(DiasMes));
        }


        private void BtnMesAnterior_Click(object sender, RoutedEventArgs e)
        {
            FechaSeleccionada = FechaSeleccionada.AddMonths(-1);
        }

        private void BtnMesSiguiente_Click(object sender, RoutedEventArgs e)
        {
            FechaSeleccionada = FechaSeleccionada.AddMonths(1);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button botonDia = (Button)sender;
            DiaViewModel diaViewModel = (DiaViewModel)botonDia.DataContext;
            if (diaViewModel.EsDiaDelMes)
            {
                FechaSeleccionada = new DateTime(FechaSeleccionada.Year, FechaSeleccionada.Month, diaViewModel.Dia);
            }
        }
        public class DiaViewModel
        {
            public int Dia { get; set; }
            public bool EsDiaDelMes { get; set; }
        }
    }
}