﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoMascotas2.Model
{
    public class Mascota : INotifyPropertyChanged
    {
        private string nombre = string.Empty;
        private string especie = string.Empty;
        private int edad;
        private string dueño = string.Empty;

        public string Nombre
        {
            get => nombre;
            set { nombre = value; OnPropertyChanged(); }
        }

        public string Especie
        {
            get => especie;
            set { especie = value; OnPropertyChanged(); }
        }

        public int Edad
        {
            get => edad;
            set { edad = value; OnPropertyChanged(); }
        }

        public string Dueño
        {
            get => dueño;
            set { dueño = value; OnPropertyChanged(); }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? nombre = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nombre));
        }
    }
}
