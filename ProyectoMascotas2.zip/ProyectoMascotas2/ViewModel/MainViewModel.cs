﻿using ProyectoMascotas2.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;            // ✅ Esta línea soluciona el error de Application
using System.Windows.Input;

namespace ProyectoMascotas2.ViewModel
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private Mascota? _mascotaSeleccionada;

        public ObservableCollection<Mascota> Mascotas { get; set; } = new();

        public Mascota? MascotaSeleccionada
        {
            get => _mascotaSeleccionada;
            set
            {
                _mascotaSeleccionada = value;
                OnPropertyChanged();
            }
        }

        public ICommand ComandoAgregar => new RelayCommand(_ =>
        {
            var nuevaMascota = new Mascota();
            var ventana = new AgregarMascotaWindow
            {
                DataContext = new MascotaViewModel(nuevaMascota),
                Owner = Application.Current.MainWindow
            };

            if (ventana.ShowDialog() == true)
            {
                Mascotas.Add(nuevaMascota);
            }
        });

        public ICommand ComandoModificar => new RelayCommand(_ =>
        {
            if (MascotaSeleccionada != null)
            {
                var copia = new Mascota
                {
                    Nombre = MascotaSeleccionada.Nombre,
                    Especie = MascotaSeleccionada.Especie,
                    Edad = MascotaSeleccionada.Edad,
                    Dueño = MascotaSeleccionada.Dueño
                };

                var ventana = new AgregarMascotaWindow
                {
                    DataContext = new MascotaViewModel(copia),
                    Owner = Application.Current.MainWindow
                };

                if (ventana.ShowDialog() == true)
                {
                    MascotaSeleccionada.Nombre = copia.Nombre;
                    MascotaSeleccionada.Especie = copia.Especie;
                    MascotaSeleccionada.Edad = copia.Edad;
                    MascotaSeleccionada.Dueño = copia.Dueño;

                    OnPropertyChanged(nameof(Mascotas));
                }
            }
        });

        public ICommand ComandoEliminar => new RelayCommand(_ =>
        {
            if (MascotaSeleccionada != null)
            {
                Mascotas.Remove(MascotaSeleccionada);
                MascotaSeleccionada = null;
            }
        });

        public event PropertyChangedEventHandler? PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string? propiedad = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propiedad));
        }
    }
}
