﻿using ProyectoMascotas2.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoMascotas2.ViewModel
{
    public class MascotaViewModel : INotifyPropertyChanged
    {
        public Mascota Mascota { get; set; }

        public string Nombre
        {
            get => Mascota.Nombre;
            set { Mascota.Nombre = value; OnPropertyChanged(); }
        }

        public string Especie
        {
            get => Mascota.Especie;
            set { Mascota.Especie = value; OnPropertyChanged(); }
        }

        public int Edad
        {
            get => Mascota.Edad;
            set { Mascota.Edad = value; OnPropertyChanged(); }
        }

        public string Dueno
        {
            get => Mascota.Dueño;
            set { Mascota.Dueño = value; OnPropertyChanged(); }
        }

        public MascotaViewModel(Mascota mascota)
        {
            Mascota = mascota;
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? propiedad = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propiedad));
        }
    }
}
