﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PizzeriaEjercicio
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            SizeComboBox.SelectionChanged += SizeComboBox_SelectionChanged;
        }

        private void SizeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (SizeComboBox.SelectedIndex == 2) // Grande
            {
                ThinCrustCheckBox.Visibility = Visibility.Visible;
            }
            else
            {
                ThinCrustCheckBox.Visibility = Visibility.Collapsed;
            }
        }
        private void CalculateButton_Click(object sender, RoutedEventArgs e)
        {
            double totalPrice = 0;

            switch (SizeComboBox.SelectedIndex)
            {
                case 0:
                    totalPrice = 49.00;
                    break;
                case 1:
                    totalPrice = 79.00;
                    break;
                case 2:
                    totalPrice = 149.00;
                    break;
            }

            if (ExtraCheeseCheckBox.IsChecked == true && SizeComboBox.SelectedIndex != 0)
            {
                totalPrice += 15;
            }

            if (ThinCrustCheckBox.IsChecked == true && SizeComboBox.SelectedIndex == 2)
            {
                totalPrice += 40;
            }

            if (int.TryParse(IngredientsCountTextBox.Text, out int ingredientsCount) && ingredientsCount >= 0 && ingredientsCount <= 6)
            {
                totalPrice += ingredientsCount * 20;
            }
            else
            {
                MessageBox.Show("Por favor, ingrese un número válido de ingredientes adicionales (0-6).");
                return;
            }

            TotalPriceTextBlock.Text = $"Precio Total: ${totalPrice}";
        }
    }
}